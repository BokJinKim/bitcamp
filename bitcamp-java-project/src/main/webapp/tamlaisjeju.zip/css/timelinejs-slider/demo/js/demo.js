$(function () {
    if ($('.prettyprint').length) {
        window.prettyPrint && prettyPrint();
    }
});