

//템플릿 엔진이 사용할 템플릿 데이터 가져오기
var trTemplateSrc = $("#tr-template").html();

// 위에서 준비한 템플릿 데이터를 가지고 HTML을 생성할 템플릿 엔진 준비
var templateFn = Handlebars.compile(trTemplateSrc);

$.getJSON("http://localhost:8888/bitcamp-java-project/json/tour/12", (data) => {
	   var trHTML = templateFn(data);
       $(trHTML).appendTo('#tableBody');
});


$("#userArea a").live("click", function(){

var test = ($(this).attr('data-id'));

$("div[data-id='"+test+"']").css("display", "");

});

{"addr1":"제주특별자치도 서귀포시 남원읍 신례동로 256",
	"areacode":39,"cat1":"A02","cat2":"A0202","cat3":"A02020600",
	"contentid":322836,"contenttypeid":12,"createdtime":20071211113035,
	"firstimage":"http:\/\/tong.visitkorea.or.kr\/cms\/resource\/02\/2038802_image2_1.jpg",
	"firstimage2":"http:\/\/tong.visitkorea.or.kr\/cms\/resource\/02\/2038802_image2_1.jpg",
	"mapx":126.6344317363,"mapy":33.3085171454,"mlevel":6,"modifiedtime":20180403085533,
	"readcount":497876,"sigungucode":3,"title":"휴애리자연생활공원","zipcode":63608}


var people = [
  { "name": "bob", "dinner": "pizza" },
  { "name": "john", "dinner": "sushi" },
  { "name": "larry", "dinner": "hummus" }
];
 이런 식으로 배열안에 객체가 있다면 여기서 dinner가 sushi 인 사람의 이름을 가져올 때는 아래와 같다.


var men = people.filter(function (person) { return person.dinner == "sushi" });
console.log(men[0].name);
1
2
var men = people.filter(function (person) { return person.dinner == "sushi" });
console.log(men[0].name);