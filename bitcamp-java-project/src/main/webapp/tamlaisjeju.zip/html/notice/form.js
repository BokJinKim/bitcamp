
    var tags = $(".detail-view");
    tags.css("display","none"); // <h1 style="display: none;">...</h1>
    
    $("#addBtn").click(() => {
       $.post(serverRoot + "/json/notice/add", {
            title: $(TITL).val(),
            content: $(CONT).val(),
        }, () => {
            location.href = "list.html";
        });
    });

